/**
 * BACKEND del catálogo — vive dentro de tu Google Sheet (Apps Script).
 * No necesitas entender cada línea: solo pega este código donde te indica
 * la guía (INSTRUCCIONES.md) y cambia la CLAVE_ADMIN de abajo.
 */

// 🔑 Cambia esto por una clave secreta tuya. Es lo que protege quién puede
// agregar productos o registrar ventas.
const CLAVE_ADMIN = 'CAMBIA_ESTA_CLAVE_1234';

const NOMBRE_HOJA_PRODUCTOS = 'Productos';
const NOMBRE_HOJA_VENTAS = 'Ventas';

// --- Peticiones para LEER datos (el catálogo público las usa) ---
function doGet(e) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const productos = leerHoja(ss.getSheetByName(NOMBRE_HOJA_PRODUCTOS));
  return respuesta({ productos });
}

// --- Peticiones para ESCRIBIR datos (agregar producto, vender, eliminar) ---
function doPost(e) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const body = JSON.parse(e.postData.contents);

  if (body.clave !== CLAVE_ADMIN) {
    return respuesta({ error: 'Clave incorrecta' });
  }

  if (body.accion === 'agregarProducto') {
    const sh = ss.getSheetByName(NOMBRE_HOJA_PRODUCTOS);
    sh.appendRow([
      Utilities.getUuid(),
      body.nombre,
      body.categoria,
      body.precio,
      body.stock,
      body.descripcion
    ]);
    return respuesta({ ok: true });
  }

  if (body.accion === 'eliminarProducto') {
    const sh = ss.getSheetByName(NOMBRE_HOJA_PRODUCTOS);
    const datos = sh.getDataRange().getValues();
    for (let i = 1; i < datos.length; i++) {
      if (datos[i][0] === body.id) { sh.deleteRow(i + 1); break; }
    }
    return respuesta({ ok: true });
  }

  if (body.accion === 'registrarVenta') {
    const shVentas = ss.getSheetByName(NOMBRE_HOJA_VENTAS);
    const shProductos = ss.getSheetByName(NOMBRE_HOJA_PRODUCTOS);
    const total = Number(body.precioUnitario) * Number(body.cantidad);

    shVentas.appendRow([
      Utilities.getUuid(),
      new Date(),
      body.productoId,
      body.producto,
      body.cantidad,
      body.precioUnitario,
      total,
      body.cliente || ''
    ]);

    // Descontar del stock
    const datos = shProductos.getDataRange().getValues();
    for (let i = 1; i < datos.length; i++) {
      if (datos[i][0] === body.productoId) {
        const stockActual = datos[i][4];
        shProductos.getRange(i + 1, 5).setValue(Math.max(0, stockActual - Number(body.cantidad)));
        break;
      }
    }
    return respuesta({ ok: true });
  }

  return respuesta({ error: 'Acción no reconocida' });
}

// --- Funciones de apoyo, no las necesitas tocar ---
function leerHoja(sheet) {
  const datos = sheet.getDataRange().getValues();
  const headers = datos.shift();
  return datos
    .filter(fila => fila[0] !== '')
    .map(fila => {
      const obj = {};
      headers.forEach((h, i) => obj[h] = fila[i]);
      return obj;
    });
}

function respuesta(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
